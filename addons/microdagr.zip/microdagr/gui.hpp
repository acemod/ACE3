#define ST_LEFT           0x00
#define ST_RIGHT          0x01
#define ST_CENTER         0x02

class RscActiveText;
class RscText;
class RscPicture;
class RscMapControl {
        class hospital;
        class church;
        class lighthouse;
        class power;
        class fuelstation;
        class transmitter;
};
class RscMapControlEmpty;
class RscControlsGroupNoScrollbars;
class RscEdit;
class RscButton;
class RscListBox;


class GVAR(RscActiveTextPicture): RscActiveText {
    style = 48;
    onbuttonclick = "hint 'cen'";
    colorText[] = {1,1,1,1};
    colorActive[] = {1,1,1,1};
    color[] = {1,1,1,1};
    color2[] = {1,1,1,1};
    colorFocused[] = {1,1,1,1};
    colorDisabled[] = {1,1,1,1};
    colorBackground[] = {1,1,1,1};
    colorBackground2[] = {1,1,1,1};
    colorBackgroundFocused[] = {1,1,1,1};
};

class GVAR(RscText): RscText {
    font = "EtelkaMonospacePro";
    colorText[] = {0.75,0.75,0.75,1};
};

//Redfine Scaling for the Dialog
#define X_PART(num) QUOTE((((60 - 25)/2) + (num)) * (safeZoneH / 64) + (safezoneX + (safezoneW - safeZoneH)/2))
#define Y_PART(num) QUOTE((0 + (num)) * (safeZoneH / 36) + (safezoneY + (safezoneH - (safeZoneH / 1.2))/2))
#define W_PART(num) QUOTE((num) * (safeZoneH / 64))
#define H_PART(num) QUOTE((num) * (safeZoneH / 36))

class testGPS {
    idd = -1;
    movingEnable = 1;
    duration = 9999999;
    fadein = 0;
    fadeout = 0;
    onLoad = "uiNamespace setVariable ['testGPS', _this select 0];";  //@todo cbaify this
    onUnload = QUOTE([] call FUNC(dialogClosedEH));

    #include "gui_controls.hpp"
};


//Redfine Scaling for the RscTitle
#define PROFILE_X (profilenamespace getvariable ['IGUI_GRID_GPS_X', 0])
#define PROFILE_Y (profilenamespace getvariable ['IGUI_GRID_GPS_Y', 0])
#define PROFILE_W (profilenamespace getvariable ['IGUI_GRID_GPS_W', 1])
#define PROFILE_H ((16/9) * (profilenamespace getvariable ['IGUI_GRID_GPS_W', 1]))

#define X_PART(num) QUOTE((num) / 25 * PROFILE_W + PROFILE_X)
#define Y_PART(num) QUOTE((num) / 25 * PROFILE_H + PROFILE_Y)
#define W_PART(num) QUOTE((num) / 25 * PROFILE_W)
#define H_PART(num) QUOTE((num) / 25 * PROFILE_H)

class RscTitles {
    class testGPS_T {
        idd = -1;
        movingEnable = 1;
        duration = 9999999;
        fadein = 0;
        fadeout = 0;
        onLoad = "uiNamespace setVariable ['testGPS_T', _this select 0];";  //@todo cbaify this

        #include "gui_controls.hpp"
    };
};
